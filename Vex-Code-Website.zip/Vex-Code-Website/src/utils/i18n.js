import { translations, rtlLangs, langLabels, defaultLang } from '../translations/index.js';

const STORAGE_KEY = 'vexcode-lang';

export function detectInitialLang() {
  const saved = localStorage.getItem(STORAGE_KEY);
  if (saved && translations[saved]) return saved;

  const browserLang = (navigator.language || defaultLang).slice(0, 2);
  if (translations[browserLang]) return browserLang;

  return defaultLang;
}

export function t(lang, key) {
  const dict = translations[lang] || translations[defaultLang];
  return dict[key] || translations[defaultLang][key] || key;
}

export function applyLanguage(lang, onChange) {
  if (!translations[lang]) lang = defaultLang;

  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    const value = t(lang, key);
    if (value) el.textContent = value;
  });

  document.documentElement.lang = lang;
  document.documentElement.dir = rtlLangs.includes(lang) ? 'rtl' : 'ltr';

  document.querySelectorAll('[data-lang-label]').forEach((el) => {
    el.textContent = langLabels[lang];
  });

  document.querySelectorAll('[data-lang-option]').forEach((btn) => {
    btn.classList.toggle('active', btn.dataset.langOption === lang);
  });

  localStorage.setItem(STORAGE_KEY, lang);

  if (typeof onChange === 'function') onChange(lang);
}

export { translations, rtlLangs, langLabels };
