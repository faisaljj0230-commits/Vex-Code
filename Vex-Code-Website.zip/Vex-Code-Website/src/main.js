import './styles/main.css';

import { renderNavbar, initNavbar } from './components/navbar.js';
import { renderMobileMenu, initMobileMenu } from './components/mobileMenu.js';
import { renderFooter } from './components/footer.js';
import { initFaqAccordion } from './components/faqAccordion.js';

import { renderHero } from './sections/hero.js';
import { renderServices } from './sections/services.js';
import { renderWhy } from './sections/why.js';
import { renderProjectsSection, renderProjectCards } from './sections/projects.js';
import { renderHowItWorks } from './sections/howItWorks.js';
import { renderAbout } from './sections/about.js';
import { renderFaq } from './sections/faq.js';
import { renderCta } from './sections/cta.js';

import { detectInitialLang, applyLanguage } from './utils/i18n.js';
import { initScrollReveal } from './utils/reveal.js';

function mount() {
  document.querySelector('header').innerHTML = renderNavbar();
  document.getElementById('mobileMenu').innerHTML = renderMobileMenu();

  document.getElementById('main').innerHTML =
    renderHero() +
    renderServices() +
    renderWhy() +
    renderProjectsSection() +
    renderHowItWorks() +
    renderAbout() +
    renderFaq() +
    renderCta();

  document.querySelector('footer').innerHTML = renderFooter();
}

function init() {
  mount();

  initNavbar();
  initMobileMenu();
  initFaqAccordion();
  initScrollReveal();

  const lang = detectInitialLang();
  applyLanguage(lang, renderProjectCards);

  document.querySelectorAll('[data-lang-option]').forEach((btn) => {
    btn.addEventListener('click', () => {
      applyLanguage(btn.dataset.langOption, renderProjectCards);
      document.getElementById('langMenu').classList.remove('open');
    });
  });
}

document.addEventListener('DOMContentLoaded', init);
