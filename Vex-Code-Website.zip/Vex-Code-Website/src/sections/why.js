function whyItem(num, titleKey, descKey) {
  return `
    <div class="why-item reveal">
      <div class="why-num">${num}</div>
      <h3 data-i18n="${titleKey}"></h3>
      <p data-i18n="${descKey}"></p>
    </div>
  `;
}

export function renderWhy() {
  return `
    <section class="why-section">
      <div class="wrap">
        <div class="section-head reveal">
          <div class="eyebrow" data-i18n="why.eyebrow">Why Vex Code?</div>
          <h2 class="section-title" data-i18n="why.title">Why Vex Code?</h2>
          <p class="section-desc" data-i18n="why.desc">We focus on more than just writing code. We create reliable, modern and carefully designed solutions that are built to perform.</p>
        </div>

        <div class="why-list">
          ${whyItem('01', 'why.quality.title', 'why.quality.desc')}
          ${whyItem('02', 'why.performance.title', 'why.performance.desc')}
          ${whyItem('03', 'why.custom.title', 'why.custom.desc')}
          ${whyItem('04', 'why.support.title', 'why.support.desc')}
        </div>
      </div>
    </section>
  `;
}
