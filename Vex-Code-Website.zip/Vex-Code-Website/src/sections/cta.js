import { DISCORD_LINK } from '../data/config.js';

export function renderCta() {
  return `
    <section class="cta-section">
      <div class="wrap">
        <div class="cta-inner reveal">
          <h2 data-i18n="cta.title">Have an Idea? Let's Build It.</h2>
          <p data-i18n="cta.desc">Turn your idea into something real with Vex Code.</p>
          <a href="${DISCORD_LINK}" target="_blank" rel="noopener" class="btn btn-primary" data-i18n="cta.button">Start Your Project</a>
        </div>
      </div>
    </section>
  `;
}
