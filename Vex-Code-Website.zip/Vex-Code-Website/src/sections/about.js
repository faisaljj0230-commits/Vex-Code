export function renderAbout() {
  return `
    <section id="about" class="about-section">
      <div class="wrap">
        <div class="about-inner reveal">
          <h2 data-i18n="about.title">Built With Code. Driven By Ideas.</h2>
          <p data-i18n="about.desc">Vex Code is a digital development store focused on creating modern websites, Discord solutions, custom systems and software tailored to each client's needs.</p>
          <div class="about-tagline" data-i18n="about.tagline">Vex Code — Your Idea, Our Code.</div>
        </div>
      </div>
    </section>
  `;
}
