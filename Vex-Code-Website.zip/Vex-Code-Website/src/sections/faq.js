function faqItem(qKey, aKey) {
  return `
    <div class="faq-item">
      <button class="faq-question">
        <span data-i18n="${qKey}"></span>
        <span class="faq-icon"></span>
      </button>
      <div class="faq-answer"><p data-i18n="${aKey}"></p></div>
    </div>
  `;
}

export function renderFaq() {
  return `
    <section id="faq">
      <div class="wrap">
        <div class="section-head reveal">
          <div class="eyebrow" data-i18n="faq.eyebrow">FAQ</div>
          <h2 class="section-title" data-i18n="faq.title">Frequently Asked Questions</h2>
        </div>

        <div class="faq-list">
          ${faqItem('faq.q1.q', 'faq.q1.a')}
          ${faqItem('faq.q2.q', 'faq.q2.a')}
          ${faqItem('faq.q3.q', 'faq.q3.a')}
          ${faqItem('faq.q4.q', 'faq.q4.a')}
        </div>
      </div>
    </section>
  `;
}
