function step(num, titleKey, descKey) {
  return `
    <div class="step reveal">
      <div class="step-num">${num}</div>
      <h3 data-i18n="${titleKey}"></h3>
      <p data-i18n="${descKey}"></p>
    </div>
  `;
}

export function renderHowItWorks() {
  return `
    <section>
      <div class="wrap">
        <div class="section-head reveal">
          <div class="eyebrow" data-i18n="how.eyebrow">From Idea to Reality</div>
          <h2 class="section-title" data-i18n="how.title">From Idea to Reality</h2>
        </div>

        <div class="steps">
          ${step('01', 'how.tell.title', 'how.tell.desc')}
          ${step('02', 'how.plan.title', 'how.plan.desc')}
          ${step('03', 'how.build.title', 'how.build.desc')}
          ${step('04', 'how.deliver.title', 'how.deliver.desc')}
        </div>
      </div>
    </section>
  `;
}
