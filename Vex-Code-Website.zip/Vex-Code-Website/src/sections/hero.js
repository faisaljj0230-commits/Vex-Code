import { DISCORD_LINK } from '../data/config.js';

export function renderHero() {
  return `
    <section class="hero" id="home">
      <div class="wrap hero-content">
        <div class="hero-brand">VEX CODE</div>
        <h1 data-i18n="hero.title">Your Idea. Our Code.</h1>
        <p data-i18n="hero.desc">We build modern digital solutions designed to bring your ideas to life — from powerful websites and Discord bots to custom systems and software.</p>
        <div class="hero-buttons">
          <a href="#services" class="btn btn-outline" data-i18n="hero.explore">Explore Services</a>
          <a href="${DISCORD_LINK}" target="_blank" rel="noopener" class="btn btn-primary" data-i18n="hero.start">Start a Project</a>
        </div>
      </div>
    </section>
  `;
}
