const icons = {
  web: '<polyline points="16 18 22 12 16 6"></polyline><polyline points="8 6 2 12 8 18"></polyline>',
  personal: '<circle cx="12" cy="8" r="4"></circle><path d="M4 21v-1a8 8 0 0 1 16 0v1"></path>',
  rp: '<path d="M3 3h18v14H3z"></path><path d="M8 21h8M12 17v4"></path>',
  discord: '<rect x="3" y="5" width="18" height="14" rx="2"></rect><path d="M8 10h.01M12 10h.01M16 10h.01M8 14h6"></path>',
  custom: '<path d="M12 2 2 7l10 5 10-5-10-5Z"></path><path d="M2 17l10 5 10-5M2 12l10 5 10-5"></path>',
  devdev: '<path d="m18 16 4-4-4-4M6 8l-4 4 4 4M14.5 4l-5 16"></path>'
};

function serviceCard({ icon, titleKey, descKey, featured }) {
  return `
    <div class="service-card${featured ? ' featured' : ''} reveal">
      <div class="service-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${icons[icon]}</svg>
      </div>
      <h3 data-i18n="${titleKey}"></h3>
      <p data-i18n="${descKey}"></p>
    </div>
  `;
}

export function renderServices() {
  const cards = [
    { icon: 'web', titleKey: 'services.web.title', descKey: 'services.web.desc', featured: true },
    { icon: 'personal', titleKey: 'services.personal.title', descKey: 'services.personal.desc' },
    { icon: 'rp', titleKey: 'services.rp.title', descKey: 'services.rp.desc' },
    { icon: 'discord', titleKey: 'services.discord.title', descKey: 'services.discord.desc', featured: true },
    { icon: 'custom', titleKey: 'services.custom.title', descKey: 'services.custom.desc' },
    { icon: 'devdev', titleKey: 'services.devdev.title', descKey: 'services.devdev.desc' }
  ];

  return `
    <section id="services">
      <div class="wrap">
        <div class="section-head reveal">
          <div class="eyebrow" data-i18n="services.eyebrow">What We Build</div>
          <h2 class="section-title" data-i18n="services.title">What We Build</h2>
          <p class="section-desc" data-i18n="services.desc">Professional digital solutions built around your needs.</p>
        </div>

        <div class="services-grid">
          ${cards.map(serviceCard).join('')}
        </div>
      </div>
    </section>
  `;
}
