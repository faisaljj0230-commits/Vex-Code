import { projects } from '../data/projects.js';
import { t } from '../utils/i18n.js';

export function renderProjectsSection() {
  return `
    <section id="projects">
      <div class="wrap">
        <div class="section-head reveal">
          <div class="eyebrow" data-i18n="projects.eyebrow">Selected Projects</div>
          <h2 class="section-title" data-i18n="projects.title">Selected Projects</h2>
          <p class="section-desc" data-i18n="projects.desc">A look at some of the projects and solutions we've built.</p>
        </div>

        <div id="projectsGrid" class="projects-grid"></div>

        <div id="projectsEmpty" class="coming-soon reveal">
          <span data-i18n="projects.comingSoonTitle">Projects Coming Soon</span>
          <p data-i18n="projects.comingSoonDesc">We're preparing our portfolio. Real projects will be added here soon.</p>
        </div>
      </div>
    </section>
  `;
}

function projectCard(project, lang) {
  let html = '';

  if (project.image) {
    html += `<div class="project-image"><img src="${project.image}" alt="${project.name || ''}" loading="lazy"></div>`;
  }

  html += '<div class="project-body">';
  if (project.name) html += `<h3>${project.name}</h3>`;
  if (project.description) html += `<p>${project.description}</p>`;

  const meta = [];
  if (project.builtFor) meta.push(`${t(lang, 'projects.builtFor')}: ${project.builtFor}`);
  if (project.type) meta.push(project.type);
  if (meta.length) {
    html += `<div class="project-meta">${meta.map((m) => `<span class="project-tag">${m}</span>`).join('')}</div>`;
  }

  if (project.technologies && project.technologies.length) {
    html += `<div class="project-meta">${project.technologies.map((tech) => `<span class="project-tag">${tech}</span>`).join('')}</div>`;
  }

  if (project.link) {
    html += `<a class="project-link" href="${project.link}" target="_blank" rel="noopener">${t(lang, 'projects.viewProject')} →</a>`;
  }

  html += '</div>';

  return `<div class="project-card reveal in">${html}</div>`;
}

export function renderProjectCards(lang) {
  const grid = document.getElementById('projectsGrid');
  const empty = document.getElementById('projectsEmpty');
  if (!grid || !empty) return;

  if (!projects.length) {
    grid.style.display = 'none';
    empty.style.display = 'block';
    return;
  }

  empty.style.display = 'none';
  grid.style.display = 'grid';
  grid.innerHTML = projects.map((p) => projectCard(p, lang)).join('');
}
