// Central place for anything that might need to change later.
// The Discord link is used everywhere in the site through this file only.

export const DISCORD_LINK = 'https://discord.gg/zwdhGyX2P';

export const SITE = {
  brand: 'VEX CODE',
  tagline: {
    en: 'Your Idea. Our Code.',
    ar: 'فكرتك. برمجتنا.',
    tr: 'Senin Fikrin. Bizim Kodumuz.',
    de: 'Deine Idee. Unser Code.',
    it: 'La Tua Idea. Il Nostro Codice.'
  },
  year: 2026
};
