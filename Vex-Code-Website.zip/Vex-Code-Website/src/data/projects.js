// Real projects go here later. Each project supports the fields below.
// Any field you leave out is simply hidden in the UI — nothing is invented.
//
// {
//   name: 'Project Name',
//   image: '/assets/projects/example.jpg',
//   description: 'What the project is, what we developed, main features, purpose.',
//   builtFor: 'Client Name',
//   type: 'Website', // Website | Discord Bot | Custom System
//   technologies: ['JavaScript', 'HTML', 'CSS'],
//   link: 'https://example.com'
// }

export const projects = [];
