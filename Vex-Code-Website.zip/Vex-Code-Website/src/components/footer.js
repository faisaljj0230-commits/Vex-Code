import { DISCORD_LINK, SITE } from '../data/config.js';
import logo from '../../assets/logo/vex-code-logo.png';

export function renderFooter() {
  return `
    <div class="wrap">
      <div class="footer-top">
        <div class="footer-brand">
          <a href="#home" class="brand">
            <img src="${logo}" alt="${SITE.brand}">
            <span>${SITE.brand}</span>
          </a>
          <p data-i18n="footer.tagline">Your Idea. Our Code.</p>
        </div>

        <div class="footer-links">
          <a href="#services" data-i18n="nav.services">Services</a>
          <a href="#projects" data-i18n="nav.projects">Projects</a>
          <a href="#about" data-i18n="nav.about">About</a>
          <a href="#faq" data-i18n="nav.faq">FAQ</a>
          <a href="${DISCORD_LINK}" target="_blank" rel="noopener">Discord</a>
        </div>
      </div>

      <div class="footer-bottom">
        <span>&copy; ${SITE.year} ${SITE.brand}. All rights reserved.</span>
      </div>
    </div>
  `;
}
