import { DISCORD_LINK } from '../data/config.js';

export function renderMobileMenu() {
  return `
    <a href="#home" data-i18n="nav.home">Home</a>
    <a href="#services" data-i18n="nav.services">Services</a>
    <a href="#projects" data-i18n="nav.projects">Projects</a>
    <a href="#about" data-i18n="nav.about">About</a>
    <a href="#faq" data-i18n="nav.faq">FAQ</a>
    <a href="${DISCORD_LINK}" target="_blank" rel="noopener" class="btn btn-primary" data-i18n="nav.cta">Start a Project</a>
  `;
}

export function initMobileMenu() {
  const toggle = document.getElementById('menuToggle');
  const menu = document.getElementById('mobileMenu');

  toggle.addEventListener('click', () => {
    toggle.classList.toggle('active');
    menu.classList.toggle('open');
  });

  menu.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => {
      toggle.classList.remove('active');
      menu.classList.remove('open');
    });
  });
}
