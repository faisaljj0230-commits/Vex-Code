import { DISCORD_LINK, SITE } from '../data/config.js';
import logo from '../../assets/logo/vex-code-logo.png';

export function renderNavbar() {
  return `
    <div class="wrap nav-inner">
      <a href="#home" class="brand">
        <img src="${logo}" alt="${SITE.brand}">
        <span>${SITE.brand}</span>
      </a>

      <nav class="nav-links">
        <a href="#home" data-i18n="nav.home">Home</a>
        <a href="#services" data-i18n="nav.services">Services</a>
        <a href="#projects" data-i18n="nav.projects">Projects</a>
        <a href="#about" data-i18n="nav.about">About</a>
        <a href="#faq" data-i18n="nav.faq">FAQ</a>
      </nav>

      <div class="nav-right">
        <div class="lang-select">
          <button class="lang-btn" id="langBtn">
            <span data-lang-label>EN</span>
          </button>
          <div class="lang-menu" id="langMenu">
            <button data-lang-option="en">English</button>
            <button data-lang-option="ar">العربية</button>
            <button data-lang-option="tr">Türkçe</button>
            <button data-lang-option="de">Deutsch</button>
            <button data-lang-option="it">Italiano</button>
          </div>
        </div>

        <a href="${DISCORD_LINK}" target="_blank" rel="noopener" class="btn btn-primary nav-cta" data-i18n="nav.cta">Start a Project</a>

        <button class="menu-toggle" id="menuToggle" aria-label="Menu">
          <span></span><span></span><span></span>
        </button>
      </div>
    </div>
  `;
}

export function initNavbar() {
  const langBtn = document.getElementById('langBtn');
  const langMenu = document.getElementById('langMenu');

  langBtn.addEventListener('click', () => {
    langMenu.classList.toggle('open');
  });

  document.addEventListener('click', (e) => {
    if (!langBtn.contains(e.target) && !langMenu.contains(e.target)) {
      langMenu.classList.remove('open');
    }
  });

  return { langMenu };
}
