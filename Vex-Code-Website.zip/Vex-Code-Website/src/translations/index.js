import en from './en.js';
import ar from './ar.js';
import tr from './tr.js';
import de from './de.js';
import it from './it.js';

export const translations = { en, ar, tr, de, it };

export const rtlLangs = ['ar'];

export const langLabels = {
  en: 'EN',
  ar: 'عربي',
  tr: 'TR',
  de: 'DE',
  it: 'IT'
};

export const defaultLang = 'en';
