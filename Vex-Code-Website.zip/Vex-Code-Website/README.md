# Vex Code — Website

Official website for **Vex Code**, built as a static multi-language site with Vite (no framework, plain JavaScript/HTML/CSS).

## Requirements

- Node.js 18 or newer
- npm (comes with Node.js)

## Install dependencies

```bash
npm install
```

## Run locally

```bash
npm run dev
```

This starts a local dev server (Vite will print the address, usually `http://localhost:5173`) with hot reload.

## Build for production

```bash
npm run build
```

The finished, optimized site is generated in the `dist/` folder — upload the contents of that folder to any static host.

To preview the production build locally before deploying:

```bash
npm run preview
```

## Project structure

```text
Vex-Code-Website/
├── assets/
│   ├── logo/            → the Vex Code logo
│   ├── projects/        → project screenshots (add here when ready)
│   └── icons/           → any extra icon assets
├── src/
│   ├── components/      → navbar, mobile menu, footer, FAQ accordion
│   ├── sections/        → hero, services, why us, projects, how it works, about, FAQ, CTA
│   ├── data/
│   │   ├── config.js    → the Discord link and site-wide constants
│   │   └── projects.js  → the project list (empty by default)
│   ├── translations/    → one file per language (ar, en, tr, de, it)
│   ├── styles/          → CSS split by concern (variables, base, components, sections, animations)
│   └── utils/           → language switching + scroll-reveal logic
├── index.html
├── package.json
└── vite.config.js
```

## Where to change things

- **Discord link** — `src/data/config.js`, the `DISCORD_LINK` constant. Every button and link on the site (navbar, hero, footer, final CTA) reads from this single value.
- **Adding projects** — `src/data/projects.js`. Add an object to the `projects` array with any of: `name`, `image`, `description`, `builtFor`, `type`, `technologies`, `link`. Leave a field out and it's simply hidden — nothing is invented. Put project images in `assets/projects/` and reference them from there (e.g. `/assets/projects/my-project.jpg`). While the array is empty, the site automatically shows the "Projects Coming Soon" state.
- **Editing translations** — `src/translations/`, one file per language (`ar.js`, `en.js`, `tr.js`, `de.js`, `it.js`). Each is a flat key → text object; edit the text on the right of any line to change it. Adding a new key requires adding it to all five files plus a matching `data-i18n="your.key"` attribute in the relevant file under `src/sections/` or `src/components/`.
- **Replacing the logo** — swap the file at `assets/logo/vex-code-logo.png` (keep the same filename, or update the two `import logo from ...` lines in `src/components/navbar.js` and `src/components/footer.js` if you rename it).

## Notes

- Arabic (`ar`) automatically switches the whole page to RTL — layout, spacing and the FAQ/nav/footer all mirror correctly since the CSS uses logical properties (`margin-inline`, `padding-inline`, `border-inline-start`, etc.) instead of hardcoded left/right values.
- The selected language is remembered via `localStorage`; on a first visit the browser's language is used if it's one of the five supported, otherwise it defaults to English.
- No pricing, checkout, fake statistics, fake reviews, fake clients or fake team members are included anywhere, per the project brief — every order/contact path goes through the Discord link above.

---

# Vex Code — الموقع الرسمي

الموقع الرسمي لمتجر **Vex Code**، مبني كموقع ثابت متعدد اللغات باستخدام Vite (بدون أي Framework، JavaScript وHTML وCSS فقط).

## المتطلبات

- Node.js إصدار 18 أو أحدث
- npm (يأتي مع Node.js)

## تثبيت الحزم

```bash
npm install
```

## تشغيل الموقع محلياً

```bash
npm run dev
```

## بناء نسخة الإنتاج (Build)

```bash
npm run build
```

الناتج النهائي سيكون داخل مجلد `dist/` — ارفع محتوى هذا المجلد على أي استضافة Static.

## أين تعدّل الأشياء المهمة

- **رابط الديسكورد** — في `src/data/config.js`, المتغير `DISCORD_LINK`. كل زر ورابط في الموقع يقرأ من هذا المكان فقط.
- **إضافة المشاريع** — في `src/data/projects.js`. أضف عنصر جديد في مصفوفة `projects` بالحقول: `name`, `image`, `description`, `builtFor`, `type`, `technologies`, `link`. أي حقل تتركه فارغاً يُخفى تلقائياً. ضع صور المشاريع داخل `assets/projects/`.
- **تعديل الترجمات** — داخل `src/translations/`، ملف مستقل لكل لغة (`ar.js`, `en.js`, `tr.js`, `de.js`, `it.js`).
- **استبدال اللوقو** — استبدل الملف في `assets/logo/vex-code-logo.png` بنفس الاسم.
